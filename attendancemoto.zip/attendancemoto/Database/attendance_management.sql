-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2020 at 12:30 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `student` varchar(40) DEFAULT NULL,
  `regno` varchar(40) DEFAULT NULL,
  `week` varchar(40) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `unit` int(10) UNSIGNED DEFAULT NULL,
  `attended` varchar(40) DEFAULT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`student`, `regno`, `week`, `date`, `unit`, `attended`, `id`) VALUES
('BSIT/123/16', 'BSIT/123/16', '1', '2020-01-21', 2, '1', 8),
('BSIT/123/16', 'BSIT/123/16', '1', '2020-01-21', 2, '1', 9),
('BSIT/123/16', 'BSIT/123/16', '1', '2020-01-22', 2, '1', 10),
('3434', '3434', '1', '2020-01-04', 1, '1', 11),
('3434', '3434', '1', '2020-01-05', 1, NULL, 12),
('dota', 'dota', '1', '2020-02-05', 1, '1', 13),
('dota', 'dota', '1', '2020-02-06', 1, NULL, 14),
('4444', '4444', '1', '2020-02-04', 1, '1', 15);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`) VALUES
(1, 'Information Technology'),
(2, 'Computer Science'),
(3, 'Bussiness Administration');

-- --------------------------------------------------------

--
-- Table structure for table `membership_grouppermissions`
--

CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT 0,
  `allowEdit` tinyint(4) NOT NULL DEFAULT 0,
  `allowDelete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_grouppermissions`
--

INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES
(1, 2, 'students', 1, 3, 3, 3),
(2, 2, 'units', 1, 3, 3, 3),
(3, 2, 'courses', 1, 3, 3, 3),
(4, 2, 'attendance', 1, 3, 3, 3),
(25, 1, 'students', 0, 0, 0, 0),
(26, 1, 'units', 0, 0, 0, 0),
(27, 1, 'courses', 0, 0, 0, 0),
(28, 1, 'attendance', 0, 0, 0, 0),
(35, 4, 'courses', 0, 0, 0, 0),
(34, 4, 'units', 0, 0, 0, 0),
(33, 4, 'students', 0, 0, 0, 0),
(36, 4, 'attendance', 0, 0, 0, 0),
(37, 5, 'students', 0, 0, 0, 0),
(38, 5, 'units', 0, 0, 0, 0),
(39, 5, 'courses', 0, 0, 0, 0),
(40, 5, 'attendance', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_groups`
--

CREATE TABLE `membership_groups` (
  `groupID` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_groups`
--

INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES
(1, 'anonymous', 'This is The anonymous group BSIT 1A', 0, 0),
(2, 'Admins', 'Admin group created automatically on 2018-01-30', 0, 1),
(4, 'SAINT JUDE COLLEGE B', 'Ultimatinum', 1, 1),
(5, 'MGA MANDIRIGMA', 'WARRIOR', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `membership_userpermissions`
--

CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT 0,
  `allowEdit` tinyint(4) NOT NULL DEFAULT 0,
  `allowDelete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_userpermissions`
--

INSERT INTO `membership_userpermissions` (`permissionID`, `memberID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES
(1, 'mamawako', 'students', 0, 3, 0, 0),
(2, 'mamawako', 'units', 0, 3, 0, 0),
(3, 'mamawako', 'courses', 0, 3, 0, 0),
(4, 'mamawako', 'attendance', 0, 3, 0, 0),
(5, 'bataspinakamalakas', 'students', 0, 3, 0, 0),
(6, 'bataspinakamalakas', 'units', 0, 3, 0, 0),
(7, 'bataspinakamalakas', 'courses', 0, 3, 0, 0),
(8, 'bataspinakamalakas', 'attendance', 0, 3, 0, 0),
(9, 'witwew', 'students', 0, 3, 0, 0),
(10, 'witwew', 'units', 0, 3, 0, 0),
(11, 'witwew', 'courses', 0, 3, 0, 0),
(12, 'witwew', 'attendance', 0, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_userrecords`
--

CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) UNSIGNED NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) UNSIGNED DEFAULT NULL,
  `dateUpdated` bigint(20) UNSIGNED DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_userrecords`
--

INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES
(1, 'courses', '1', 'admin', 1517324670, 1580738695, 2),
(2, 'courses', '2', 'admin', 1517324701, 1517324701, 2),
(3, 'courses', '3', 'admin', 1517324738, 1517324738, 2),
(4, 'units', '1', 'admin', 1517324782, 1580739705, 2),
(5, 'units', '2', 'admin', 1517324809, 1580739714, 2),
(20, 'attendance', '10', 'admin', 1580739281, 1580739281, 2),
(19, 'attendance', '9', 'admin', 1580739245, 1580739245, 2),
(18, 'attendance', '8', 'admin', 1580739201, 1580739201, 2),
(16, 'students', 'BSIT/123/16', 'admin', 1580739042, 1580739042, 2),
(15, 'students', 'BSIT/188/16', 'admin', 1580739023, 1580739023, 2),
(21, 'units', '3', 'admin', 1580739729, 1580739729, 2),
(22, 'students', '3434', 'admin', 1580815286, 1580815286, 2),
(23, 'attendance', '11', 'admin', 1580815352, 1580815352, 2),
(24, 'attendance', '12', 'admin', 1580815448, 1580815448, 2),
(25, 'students', 'dota', 'admin', 1580815490, 1580815490, 2),
(26, 'attendance', '13', 'admin', 1580815508, 1580815547, 2),
(27, 'attendance', '14', 'admin', 1580815573, 1580815573, 2),
(28, 'students', '4444', 'admin', 1580815640, 1580815640, 2),
(29, 'attendance', '15', 'admin', 1580815657, 1580815657, 2);

-- --------------------------------------------------------

--
-- Table structure for table `membership_users`
--

CREATE TABLE `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) UNSIGNED DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text DEFAULT NULL,
  `custom2` text DEFAULT NULL,
  `custom3` text DEFAULT NULL,
  `custom4` text DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_users`
--

INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES
('guest', NULL, NULL, '2018-01-30', 1, 0, 1, NULL, NULL, NULL, NULL, 'Anonymous member created automatically on 2018-01-30', NULL, NULL),
('admin', '21232f297a57a5a743894a0e4a801fc3', 'gloda123@yahoo.com', '2018-01-30', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2018-01-30\nRecord updated automatically on 2020-02-03\nRecord updated automatically on 2020-02-04', NULL, NULL),
('bataspinakamalakas', '4d38abc9cdfed7a144e33ba47028ed54', 'batas@yahoo.com', '2020-02-03', 4, 0, 1, 'bataspinakamalakas', 'batasstrong@yahoo.com', 'kahitsaan', 'idontknow', 'ewan', NULL, NULL),
('mamawako', '65b0c95fe0b45875091e0e3386590087', 'mamawako@yahoo.com', '2020-02-03', 4, 0, 1, 'getalon', 'unalo', 'city@yahoo.com', 'kahitsaan', 'anywhere', NULL, NULL),
('witwew', '3906b32fb64ce88158569af947321e45', 'witwew123@yahoo.com', '2020-02-04', 5, 0, 1, 'LeBron James', 'ohio', 'ohio', 'i dont know', 'dakdak', '07a52a20cf02b4a58500cfb1ee494721', 1580901353);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `regno` varchar(40) NOT NULL,
  `name` varchar(100) NOT NULL,
  `course` varchar(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`regno`, `name`, `course`) VALUES
('BSIT/188/16', 'Mark Ivan', '1'),
('BSIT/123/16', 'Jeric', '1'),
('3434', 'Stephen Curry', '1'),
('dota', 'Guiboyo', '1'),
('4444', 'Maria Osawa', '2');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `name`) VALUES
(1, 'ITE/299'),
(2, 'GEC'),
(3, 'BSBA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student` (`student`),
  ADD KEY `unit` (`unit`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_groups`
--
ALTER TABLE `membership_groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Indexes for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  ADD PRIMARY KEY (`recID`),
  ADD KEY `pkValue` (`pkValue`),
  ADD KEY `tableName` (`tableName`),
  ADD KEY `memberID` (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `membership_users`
--
ALTER TABLE `membership_users`
  ADD PRIMARY KEY (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`regno`),
  ADD KEY `course` (`course`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  MODIFY `permissionID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `membership_groups`
--
ALTER TABLE `membership_groups`
  MODIFY `groupID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  MODIFY `permissionID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  MODIFY `recID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
