<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = '';
	$dbDatabase = 'attendance_management';

	$adminConfig = array(
		'adminUsername' => "admin",
		'adminPassword' => "b34bb3e3050d74e39e260d3cd17fb2d2",
		'notifyAdminNewMembers' => "0",
		'defaultSignUp' => "1",
		'anonymousGroup' => "anonymous",
		'anonymousMember' => "guest",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Full Name",
		'custom2' => "Address",
		'custom3' => "City",
		'custom4' => "State",
		'MySQLDateFormat' => "2/3/20",
		'PHPDateFormat' => "2/1/20",
		'PHPDateTimeFormat' => "2/2/20",
		'senderName' => "Membership management",
		'senderEmail' => "gloda123@yahoo.com",
		'approvalSubject' => "Your membership is now approved",
		'approvalMessage' => "Dear member,\r\n\r\nYour membership is now approved by the admin. You can log in to your account here:\r\nhttp://localhost/attendancemoto\r\n\r\nGLODA <3",
		'hide_twitter_feed' => "",
		'maintenance_mode_message' => "<b>Our website is currently down for maintenance</b><br>\r\nWe expect to be back in a couple hours. Thanks for your patience.",
		'mail_function' => "mail",
		'smtp_server' => "",
		'smtp_encryption' => "",
		'smtp_port' => "25",
		'smtp_user' => "",
		'smtp_pass' => ""
	);